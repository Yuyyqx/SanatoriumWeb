// /**
//  * sanatorium模块接口列表
//  */

//  import request from '../utils/request'
//  import qs from 'qs'; // 根据需求是否导入qs模块
//  import base from './base'
 
//  const sanatorium = {    
//     // getVote(userId) {
// 	// 	return request.httpRequest(`${base.sq}/sanatorium/getVoteList/${userId}`,'GET')
// 	// },
//     // //新增党员
// 	// addCommunist(params) {
// 	// 	return request.httpRequest(`${base.sq}/communist/add`,'POST',params,0,1)
// 	// },
//      // 其他接口…………
//  }
 
//  export default sanatorium;