// /**
//  * 接口域名的管理
//  */
//  const base = {    
//     sq: 'https://www.tangyihan.top/web/sanatoriumUser/loginSanatorium',    
//     bd: 'http://xxxxx22222.com/api'
// }

// export default base;